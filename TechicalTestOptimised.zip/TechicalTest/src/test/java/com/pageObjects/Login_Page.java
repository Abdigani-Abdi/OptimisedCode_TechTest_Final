package com.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login_Page {
	WebDriver driver;
	public Login_Page(WebDriver driver) 
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(id="username")
 	WebElement txt_Username;

 @FindBy(id="password")
 	WebElement txt_password;
 
 @FindBy(xpath="//*[@id=\"login\"]/button/i")
 	WebElement btn_login;
 @FindBy(id="flash")
 	WebElement txt_display;
 
 public void setUserName(String uname)
 {
	 txt_Username.sendKeys(uname);
 }
 
 public void setpassword(String pwd)
 {
	 txt_password.sendKeys(pwd);
 } 
 public void clicklogin()
 {
	 btn_login.click();
 }
 public String captureText()
 {
	 return txt_display.getText(); 
 }
}
